=== PixGo Payments WC ===
Contributors: pixgo
Tags: woocommerce, pix, payments, pixgo
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.1.2
License: GPLv2 or later

Gateway PIX PixGo para WooCommerce.

== Installation ==

1. Upload pixgo-payments-wc.zip in Plugins > Add New > Upload Plugin.
2. Activate PixGo Payments WC.
3. Open Settings > PixGo Payments WC to check status.
4. Configure keys in WooCommerce > Settings > Payments > PixGo PIX.
5. Enable the gateway only when ready.
